/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

import Conexion.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
/**
 *
 * @author Juan
 */
public class GestionAlumnos {
    Connection con;
    Conexion miCon;
    
    public GestionAlumnos(){
        miCon = new Conexion();
        con = miCon.getConnection();
    }
    
    public Alumno obtenerAlumno(int id){
        PreparedStatement stmt = null;
        ResultSet rs; //cuando hagamos una consulta, nos la guardará en el objeto rs
        Alumno alumno;
        
        try {
            stmt = con.prepareStatement("SELECT * FROM alumnos WHERE id=?");
            stmt.setInt(1, id);
            rs = stmt.executeQuery(); //guarda la salida en el objeto rs. rs es como la tabla de la base de datos.
            if(rs.next() == true){
                String nombre = rs.getString("nombre");
                String apellidos = rs.getString("apellidos");
                int edad = rs.getInt("edad");
                int curso = rs.getInt("curso");
                String datosFamilia = rs.getString("datosfamilia");
                
                alumno = new Alumno(id,nombre,apellidos,edad,curso,datosFamilia);
                return alumno;
            }
        } catch (SQLException ex) {
            System.out.println("Error al obtener el alumno " + ex);
        }
        return null;
    }
    
    public ArrayList<Alumno> obtenerAlumnos(){
        PreparedStatement stmt = null;
        ResultSet rs;
        Alumno alumno;
        ArrayList <Alumno> alumnos = new ArrayList();
        
        try {
            stmt = con.prepareStatement("SELECT * FROM alumnos");
            rs = stmt.executeQuery();
            while(rs.next() == true){
                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");
                String apellidos = rs.getString("apellidos");
                int edad = rs.getInt("edad");
                int curso = rs.getInt("curso");
                String datosFamilia = rs.getString("datosfamilia");
                
                alumno = new Alumno(id,nombre,apellidos,edad,curso,datosFamilia);
                alumnos.add(alumno);
            }
            return alumnos;
        } catch (SQLException ex) {
            System.out.println("Error al obtener todos los alumno " + ex);
        }
        return null;
    }
    
    public boolean actualizarAlumno(Alumno alumno){
        PreparedStatement stmt = null;
        
        try {
            stmt = con.prepareStatement("UPDATE alumnos SET nombre=?, apellidos=?, edad=?, curso=?, datosfamilia=? WHERE id=?");
            stmt.setString(1,alumno.getNombre());
            stmt.setString(2,alumno.getApellidos());
            stmt.setInt(3,alumno.getEdad());
            stmt.setInt(4,alumno.getCurso());
            stmt.setString(5,alumno.getDatosFamilia());
            stmt.setInt(6, alumno.getId());
            stmt.executeUpdate();
            return true;
        } catch (SQLException ex) {
            System.out.println("Error al actualizar el alumno " + ex);
            return false;
        }
    }
    
    public boolean insertarAlumno(Alumno alumno){
        PreparedStatement stmt = null;
        
        try {
            stmt = con.prepareStatement("INSERT INTO alumnos (nombre, apellidos, edad, curso, datosfamilia) VALUES (?,?,?,?,?)");
            stmt.setString(1,alumno.getNombre());
            stmt.setString(2,alumno.getApellidos());
            stmt.setInt(3,alumno.getEdad());
            stmt.setInt(4,alumno.getCurso());
            stmt.setString(5,alumno.getDatosFamilia());
            stmt.executeUpdate();
            return true;
        } catch (SQLException ex) {
            System.out.println("Error al insertar el alumno " + ex);
            return false;
        }
    }
    
    public boolean eliminarAlumno(int id){
        PreparedStatement stmt = null;
        
        try {
            stmt = con.prepareStatement("DELETE FROM alumnos WHERE id=?");
            stmt.setInt(1, id);
            stmt.executeUpdate();
            return true;
        } catch (SQLException ex) {
            System.out.println("Error al eliminar el alumno " + ex);
            return false;
        }
    }

    private ArrayList<Alumno> newArrayList() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}