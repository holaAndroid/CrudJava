package Conexion;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Juan
 */
public class Conexion {
    String JDBC_DRIVER_CLASS = "com.mysql.cj.jdbc.Driver";
    String urlJDBC = "jdbc:mysql://localhost/imw";
    String userMYSQL = "root";
    String pswdMYSQL = "yudi0101";
    Connection con = null;
    
    public Connection getConnection(){
        try {
            Class.forName(JDBC_DRIVER_CLASS);
            con = DriverManager.getConnection(urlJDBC,userMYSQL,pswdMYSQL);
        } catch (ClassNotFoundException ex) {
            System.out.println("Error al cargar el conector JDBC");
        } catch (SQLException ex) {
            System.out.println("Error con la base de datos: " + ex);
        }
        return con;
    }
}